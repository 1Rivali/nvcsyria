export const baseUrl = "http://localhost:8000/api";
export const apiVersion = "v1";